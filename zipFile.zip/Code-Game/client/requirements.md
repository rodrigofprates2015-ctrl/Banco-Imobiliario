## Packages
socket.io-client | Real-time bidirectional communication
framer-motion | Smooth animations for UI and game tokens
clsx | Class name utility
tailwind-merge | Class name utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
